Paper: Fully-convolutional siamese networks for object tracking
Code: https://github.com/bertinetto/siamese-fc

Results for the SiamFC variant with 3 scales (SiamFC-3s in the paper) for OTB-100, OPE and TRE.

